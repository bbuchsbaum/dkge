# test-data.R
# Diagnostic tests for dkge data constructors and high-level entry point

library(testthat)

make_subject_fixture <- function(q = 3, P = 4, T = 20, seed = 101) {
  set.seed(seed)
  beta <- matrix(rnorm(q * P), q, P,
                 dimnames = list(paste0("eff", seq_len(q)), NULL))
  design <- qr.Q(qr(matrix(rnorm(T * q), T, q)))
  colnames(design) <- c("eff2", "eff1", "eff3")[seq_len(q)]
  list(beta = beta, design = design)
}

test_that("dkge_subject aligns effect names and sets defaults", {
  fx <- make_subject_fixture()
  subj <- dkge_subject(fx$beta, design = fx$design)
  expect_s3_class(subj, "dkge_subject")
  expect_equal(rownames(subj$beta), colnames(subj$design))
  expect_equal(subj$observed_rows, seq_len(nrow(subj$beta)))
  expect_equal(subj$n_clusters, ncol(fx$beta))
  expect_true(all(grepl("cluster_", subj$cluster_ids)))
})

test_that("dkge_subject carries explicit observed rows", {
  fx <- make_subject_fixture()
  subj <- dkge_subject(fx$beta, design = fx$design,
                       observed_rows = c(1L, 3L))
  expect_equal(subj$observed_rows, c(1L, 3L))

  subj_logical <- dkge_subject(fx$beta, design = fx$design,
                               observed_rows = c(TRUE, FALSE, TRUE))
  expect_equal(subj_logical$observed_rows, c(1L, 3L))

  expect_error(
    dkge_subject(fx$beta, design = fx$design,
                 observed_rows = c(TRUE, FALSE)),
    "logical `observed_rows`",
    fixed = TRUE
  )
})

test_that("dkge_data honours observed rows when effect labels are identical", {
  fx <- make_subject_fixture()
  s1 <- dkge_subject(fx$beta, fx$design, id = "s1",
                     observed_rows = c(1L, 3L))
  s2 <- dkge_subject(fx$beta, fx$design, id = "s2")
  dat <- dkge_data(list(s1, s2))

  expect_equal(dat$observed_rows[[1]], c(1L, 3L))
  expect_false(dat$provenance$obs_mask[[1]][2])
  expect_equal(unname(diag(dat$provenance$pair_counts)), c(2L, 1L, 2L))
  expect_true(all(dat$betas[[1]][2, ] == 0))
  expect_true(all(dat$designs[[1]][, 2] == 0))
})

test_that("unobserved row values cannot leak into the fitted moment", {
  fx <- make_subject_fixture(q = 3, P = 4)
  design <- fx$design[, match(rownames(fx$beta), colnames(fx$design)), drop = FALSE]
  beta_garbage <- fx$beta
  beta_garbage[2, ] <- 1e12
  s1 <- suppressWarnings(dkge_subject(beta_garbage, design, id = "s1",
                                      observed_rows = c(1L, 3L)))
  s2 <- dkge_subject(fx$beta, design, id = "s2")
  fit <- suppressWarnings(dkge_fit(
    dkge_data(list(s1, s2)), K = diag(3), rank = 2,
    w_method = "none", effect_scaling = "none"
  ))
  expected <- tcrossprod(rbind(fx$beta[1, ], 0, fx$beta[3, ])) +
    tcrossprod(fx$beta)
  expect_equal(unname(fit$effect_moment), unname(expected), tolerance = 1e-12)
})

test_that("dkge_subject validates omega", {
  fx <- make_subject_fixture()
  expect_error(dkge_subject(fx$beta, fx$design, omega = 1:2), "length", fixed = FALSE)
  expect_error(dkge_subject(fx$beta, fx$design, omega = matrix(1, 2, 2)), "clusters", fixed = FALSE)
  expect_error(dkge_subject(fx$beta, fx$design, omega = c(1, -1, 1, 1)), "non-negative", fixed = FALSE)
  expect_error(dkge_subject(fx$beta, fx$design, omega = c(1, NA, 1, 1)), "finite", fixed = FALSE)
  expect_error(
    dkge_subject(fx$beta, fx$design, omega = matrix(c(1, 2, 0, 0,
                                                      0, 1, 0, 0,
                                                      0, 0, 1, 0,
                                                      0, 0, 0, 1), 4, 4, byrow = TRUE)),
    "symmetric",
    fixed = FALSE
  )
  expect_error(
    dkge_subject(fx$beta, fx$design, omega = diag(c(1, 1, 1, -0.2))),
    "positive semidefinite",
    fixed = FALSE
  )
  ok <- dkge_subject(fx$beta, fx$design, omega = rep(1, ncol(fx$beta)))
  expect_equal(ok$omega, rep(1, ncol(fx$beta)))
})

test_that("dkge_subject list method and defaults work", {
  fx <- make_subject_fixture()
  beta <- fx$beta
  rownames(beta) <- NULL
  subj <- dkge_subject(list(beta = beta, design = fx$design, id = "id1"))
  expect_equal(subj$id, "id1")
  expect_equal(rownames(subj$beta), colnames(subj$design))
})

test_that("dkge_subject default method errors", {
  expect_error(dkge_subject(1:5), "Unsupported")
})

test_that("duplicated effect labels are rejected on subject, bundle, and union paths", {
  B <- matrix(seq_len(6), 3, 2,
              dimnames = list(c("a", "a", "b"), c("v1", "v2")))
  X <- diag(3)
  colnames(X) <- c("a", "a", "b")
  expect_error(suppressWarnings(dkge_subject(B, X)), "duplicated")
  expect_error(suppressWarnings(dkge_subject(B, X)), "a")

  expect_error(
    suppressWarnings(dkge_data(list(B, B), list(X, X))),
    "duplicated"
  )

  # Union path: s1 has a repeated label, s2 introduces a new one. Today
  # match() collapses the two `a` rows into one and zero-fills with
  # obs_mask still TRUE. The aligner must refuse instead of dropping a row.
  make_hand <- function(id, labels) {
    q <- length(labels)
    X <- diag(q)
    colnames(X) <- labels
    structure(list(
      id = id,
      beta = matrix(seq_len(q), q, 1, dimnames = list(labels, "v")),
      design = X,
      effects = labels,
      observed_rows = seq_len(q),
      omega = NULL,
      effect_n = NULL,
      effect_precision = NULL,
      effect_noise_cov = NULL,
      split_betas = NULL
    ), class = "dkge_subject")
  }
  expect_error(
    dkge:::.dkge_align_subjects_to_union(list(
      make_hand("s1", c("a", "a", "b")),
      make_hand("s2", c("a", "b", "c"))
    )),
    "duplicated"
  )
  expect_error(
    dkge_data(list(
      make_hand("s1", c("a", "a", "b")),
      make_hand("s2", c("a", "b", "c"))
    )),
    "duplicated"
  )
})

test_that("dkge_data bundles raw matrices and normalises ids", {
  fx <- make_subject_fixture()
  betas <- replicate(3, fx$beta, simplify = FALSE)
  designs <- replicate(3, fx$design, simplify = FALSE)
  dat <- dkge_data(betas, designs)
  expect_s3_class(dat, "dkge_data")
  expect_equal(length(dat$betas), 3)
  expect_equal(dat$effects, colnames(fx$design))
  expect_true(all(grepl("sub", dat$subject_ids)))
})

test_that("dkge_data aligns partial effect overlaps and records provenance", {
  beta1 <- matrix(1:4, 2, 2, dimnames = list(c("eff1", "eff2"), NULL))
  beta2 <- matrix(5:10, 2, 3, dimnames = list(c("eff2", "eff3"), NULL))
  design1 <- matrix(seq_len(10), 5, 2)
  design2 <- matrix(seq_len(10), 5, 2)
  colnames(design1) <- c("eff1", "eff2")
  colnames(design2) <- c("eff2", "eff3")
  dat <- dkge_data(list(beta1, beta2), list(design1, design2))
  expect_equal(dat$effects, c("eff1", "eff2", "eff3"))
  expect_equal(nrow(dat$betas[[1]]), 3)
  expect_equal(nrow(dat$betas[[2]]), 3)
  prov <- dat$provenance
  expect_true(is.list(prov))
  expect_equal(length(prov$effect_ids), 3)
  expect_false(prov$obs_mask[[1]][3])
  expect_false(prov$obs_mask[[2]][1])
  expect_equal(dat$observed_rows[[1]], c(1L, 2L))
  expect_equal(dat$observed_rows[[2]], c(2L, 3L))
  expect_equal(prov$observed_rows[[1]], c(1L, 2L))
  expect_equal(prov$observed_rows[[2]], c(2L, 3L))
  expect_equal(unname(diag(prov$pair_counts)), c(1L, 2L, 1L))
})

test_that("dkge_data respects provided subject ids and omega", {
  fx <- make_subject_fixture()
  betas <- replicate(2, fx$beta, simplify = FALSE)
  designs <- replicate(2, fx$design, simplify = FALSE)
  omega <- list(rep(1, ncol(fx$beta)), diag(ncol(fx$beta)))
  dat <- dkge_data(betas, designs, omega = omega, subject_ids = c("A", "B"))
  expect_equal(dat$subject_ids, c("A", "B"))
  expect_equal(dat$omega[[1]], omega[[1]])
  expect_equal(dat$omega[[2]], omega[[2]])
  expect_equal(dat$observed_rows[[1]], seq_len(dat$q))
  expect_equal(dat$provenance$observed_rows[["A"]], seq_len(dat$q))
})

test_that("dkge_data errors on mismatched effects", {
  fx <- make_subject_fixture()
  betas <- list(fx$beta, fx$beta)
  designs <- list(fx$design, fx$design)
  colnames(designs[[2]]) <- letters[1:ncol(designs[[2]])]
  expect_error(dkge_data(betas, designs), "Row names of beta matrix must match design column names")
})

make_dkge_fixture <- function(S = 3, q = 3, P = 4, T = 20, seed = 202) {
  set.seed(seed)
  betas <- replicate(S, matrix(rnorm(q * P), q, P,
                               dimnames = list(paste0("eff", seq_len(q)), NULL)), simplify = FALSE)
  designs <- replicate(S, {
    X <- matrix(rnorm(T * q), T, q)
    qr.Q(qr(X))
  }, simplify = FALSE)
  for (i in seq_along(designs)) colnames(designs[[i]]) <- paste0("eff", seq_len(q))
  list(betas = betas, designs = designs)
}

test_that("dkge high-level stores inputs when requested", {
  fx <- make_dkge_fixture()
  kernel <- diag(nrow(fx$betas[[1]]))
  fit1 <- dkge(fx$betas, designs = fx$designs, K = kernel, keep_inputs = TRUE, rank = 2)
  fit2 <- dkge(fx$betas, designs = fx$designs,
               K = list(K = kernel, info = list(type = "identity")),
               keep_inputs = FALSE, rank = 2)
  expect_true(!is.null(fit1$input))
  expect_null(fit2$input)
  expect_equal(fit2$kernel_info, list(type = "identity"))
})

test_that("dkge rejects malformed kernel metadata before field access", {
  fx <- make_dkge_fixture()
  kernel <- diag(nrow(fx$betas[[1]]))

  expect_error(
    dkge(
      fx$betas,
      designs = fx$designs,
      K = list(K = kernel, info = "identity"),
      rank = 2
    ),
    "metadata `info` must be a list or NULL; got class character",
    class = "dkge_kernel_info_error"
  )

  expect_error(
    dkge_fit(
      fx$betas,
      designs = fx$designs,
      K = list(K = kernel, info = list(info = "nested")),
      rank = 2
    ),
    "`info\\$info` must be a list or NULL",
    class = "dkge_kernel_info_error"
  )
})

test_that("dkge accepts dkge_data and omega overrides", {
  fx <- make_dkge_fixture()
  kernel <- diag(nrow(fx$betas[[1]]))
  data_bundle <- dkge_data(fx$betas, fx$designs)
  override <- lapply(fx$betas, function(b) rep(2, ncol(b)))
  fit <- dkge(data_bundle, K = kernel, Omega_list = override, rank = 2)
  expect_equal(length(fit$Omega), length(override))
  expect_equal(fit$Omega[[1]], override[[1]])
})

test_that("dkge omega overrides are validated", {
  fx <- make_dkge_fixture()
  kernel <- diag(nrow(fx$betas[[1]]))
  data_bundle <- dkge_data(fx$betas, fx$designs)

  bad_override <- lapply(fx$betas, function(B) rep(1, ncol(B)))
  bad_override[[1]][1] <- -0.1

  expect_error(
    dkge(data_bundle, K = kernel, Omega_list = bad_override, rank = 2),
    "non-negative",
    fixed = FALSE
  )
})

# -------------------------------------------------------------------------
# Ordering invariance tests -----------------------------------------------
# -------------------------------------------------------------------------

test_that("dkge_data produces identical aligned effects regardless of input effect order", {
  withr::local_seed(999)
  # Create two subjects with permuted effect ordering
  effects_order1 <- c("eff1", "eff2", "eff3")
  effects_order2 <- c("eff3", "eff1", "eff2")  # permuted

  beta1 <- matrix(rnorm(3 * 10), 3, 10, dimnames = list(effects_order1, NULL))
  beta2 <- matrix(rnorm(3 * 10), 3, 10, dimnames = list(effects_order2, NULL))

  design1 <- matrix(rnorm(20 * 3), 20, 3, dimnames = list(NULL, effects_order1))
  design2 <- matrix(rnorm(20 * 3), 20, 3, dimnames = list(NULL, effects_order2))

  data <- dkge_data(list(beta1, beta2), list(design1, design2))

  # All outputs should have consistent effect ordering
  expect_identical(rownames(data$betas[[1]]), rownames(data$betas[[2]]))
  expect_identical(colnames(data$designs[[1]]), colnames(data$designs[[2]]))
  expect_identical(data$effects, rownames(data$betas[[1]]))
})

test_that("dkge_data is invariant to subject list ordering", {
  withr::local_seed(888)
  beta_a <- matrix(rnorm(3 * 10), 3, 10, dimnames = list(c("e1", "e2", "e3"), NULL))
  beta_b <- matrix(rnorm(3 * 10), 3, 10, dimnames = list(c("e1", "e2", "e3"), NULL))
  design_a <- matrix(rnorm(20 * 3), 20, 3, dimnames = list(NULL, c("e1", "e2", "e3")))
  design_b <- matrix(rnorm(20 * 3), 20, 3, dimnames = list(NULL, c("e1", "e2", "e3")))

  data1 <- dkge_data(list(beta_a, beta_b), list(design_a, design_b),
                     subject_ids = c("A", "B"))
  data2 <- dkge_data(list(beta_b, beta_a), list(design_b, design_a),
                     subject_ids = c("B", "A"))

  # Effects should be identical
  expect_identical(data1$effects, data2$effects)
  # Subject A's data should be identical in both
  idx1 <- which(data1$subject_ids == "A")
  idx2 <- which(data2$subject_ids == "A")
  expect_equal(data1$betas[[idx1]], data2$betas[[idx2]])
})

test_that("provenance correctly tracks effect coverage with partial overlap", {
  beta1 <- matrix(1:6, 2, 3, dimnames = list(c("e1", "e2"), NULL))
  beta2 <- matrix(1:6, 2, 3, dimnames = list(c("e2", "e3"), NULL))
  design1 <- matrix(1:10, 5, 2, dimnames = list(NULL, c("e1", "e2")))
  design2 <- matrix(1:10, 5, 2, dimnames = list(NULL, c("e2", "e3")))

  data <- dkge_data(list(beta1, beta2), list(design1, design2))
  prov <- data$provenance

  # e1: only subject 1, e2: both, e3: only subject 2
  expect_equal(prov$pair_counts["e1", "e1"], 1L)
  expect_equal(prov$pair_counts["e2", "e2"], 2L)
  expect_equal(prov$pair_counts["e3", "e3"], 1L)
  expect_equal(prov$pair_counts["e1", "e3"], 0L)  # No subject has both
  expect_equal(prov$observed_rows[[1]], c(1L, 2L))
  expect_equal(prov$observed_rows[[2]], c(2L, 3L))
})

test_that("effect alignment produces correct values after reordering", {
  withr::local_seed(777)
  # Create two subjects with known values in specific effect positions
  beta_orig <- matrix(1:9, 3, 3, dimnames = list(c("A", "B", "C"), NULL))
  # Create the same beta with permuted row order
  beta_perm <- beta_orig[c("C", "A", "B"), ]

  # Second subject (normal beta) to meet minimum 2-subject requirement
  beta_other <- matrix(10:18, 3, 3, dimnames = list(c("A", "B", "C"), NULL))

  design_orig <- matrix(rnorm(20 * 3), 20, 3, dimnames = list(NULL, c("A", "B", "C")))
  design_perm <- design_orig[, c("C", "A", "B")]
  colnames(design_perm) <- c("C", "A", "B")

  data1 <- suppressWarnings(dkge_data(list(beta_orig, beta_other), list(design_orig, design_orig)))
  data2 <- suppressWarnings(dkge_data(list(beta_perm, beta_other), list(design_perm, design_orig)))

  # Effect order follows first subject's design column order
  # Both should preserve all effects, though order may differ
  expect_setequal(data1$effects, data2$effects)
  # Values for each effect should be the same regardless of input order
  expect_equal(data1$betas[[1]]["A", ], data2$betas[[1]]["A", ])
  expect_equal(data1$betas[[1]]["B", ], data2$betas[[1]]["B", ])
  expect_equal(data1$betas[[1]]["C", ], data2$betas[[1]]["C", ])
})

# -------------------------------------------------------------------------
# Subject identity, effect order, and coverage guards
# -------------------------------------------------------------------------

test_that("dkge_data rejects duplicate subject identifiers", {
  fx <- make_subject_fixture()
  betas <- replicate(3, fx$beta, simplify = FALSE)
  designs <- replicate(3, fx$design, simplify = FALSE)

  expect_error(
    dkge_data(betas, designs, subject_ids = c("s1", "s1", "s2")),
    "unique"
  )

  # Also when the duplicate arrives on pre-built dkge_subject objects.
  subs <- lapply(betas, function(B) {
    dkge_subject(B, design = fx$design, id = "same")
  })
  expect_error(dkge_data(subs), "unique")
})

test_that("duplicate ids cannot make two subjects share one observation mask", {
  beta1 <- matrix(1:4, 2, 2, dimnames = list(c("eff1", "eff2"), NULL))
  beta2 <- matrix(5:8, 2, 2, dimnames = list(c("eff2", "eff3"), NULL))
  design1 <- matrix(seq_len(10), 5, 2, dimnames = list(NULL, c("eff1", "eff2")))
  design2 <- matrix(seq_len(10), 5, 2, dimnames = list(NULL, c("eff2", "eff3")))

  expect_error(
    dkge_data(list(beta1, beta2), list(design1, design2),
              subject_ids = c("dup", "dup")),
    "unique"
  )
})

test_that("dkge_data(effects=) pins the global effect order", {
  beta1 <- matrix(1:4, 2, 2, dimnames = list(c("eff1", "eff2"), NULL))
  beta2 <- matrix(5:8, 2, 2, dimnames = list(c("eff2", "eff3"), NULL))
  design1 <- matrix(seq_len(10), 5, 2, dimnames = list(NULL, c("eff1", "eff2")))
  design2 <- matrix(seq_len(10), 5, 2, dimnames = list(NULL, c("eff2", "eff3")))

  default <- dkge_data(list(beta1, beta2), list(design1, design2))
  expect_equal(default$effects, c("eff1", "eff2", "eff3"))

  pinned <- dkge_data(list(beta1, beta2), list(design1, design2),
                      effects = c("eff3", "eff1", "eff2"))
  expect_equal(pinned$effects, c("eff3", "eff1", "eff2"))

  perm <- match(pinned$effects, default$effects)
  # Betas, designs, masks and pair counts all follow the pinned order.
  expect_equal(pinned$betas[[1]], default$betas[[1]][perm, , drop = FALSE])
  expect_equal(pinned$designs[[2]], default$designs[[2]][, perm, drop = FALSE])
  expect_equal(unname(pinned$provenance$obs_mask[[2]]),
               unname(default$provenance$obs_mask[[2]])[perm])
  expect_equal(unname(pinned$provenance$pair_counts),
               unname(default$provenance$pair_counts[perm, perm]))
  expect_equal(pinned$provenance$coverage$effect, pinned$effects)

  expect_error(
    dkge_data(list(beta1, beta2), list(design1, design2),
              effects = c("eff1", "eff2")),
    "permutation"
  )
  expect_error(
    dkge_data(list(beta1, beta2), list(design1, design2),
              effects = c("eff1", "eff2", "eff3", "eff4")),
    "Unknown: eff4"
  )
})

test_that("dkge_data(effects=) reorders per-effect subject metadata", {
  q <- 3
  P <- 4
  effects <- paste0("eff", seq_len(q))
  design <- matrix(rnorm(12 * q), 12, q, dimnames = list(NULL, effects))
  make_subj <- function(id, seed) {
    set.seed(seed)
    beta <- matrix(rnorm(q * P), q, P, dimnames = list(effects, NULL))
    noise <- diag(c(1, 2, 3))
    dimnames(noise) <- list(effects, effects)
    dkge_subject(beta, design = design, id = id,
                 effect_n = stats::setNames(c(10, 20, 30), effects),
                 effect_precision = stats::setNames(c(0.1, 0.2, 0.3), effects),
                 effect_noise_cov = noise,
                 split_betas = list(beta, beta))
  }
  subs <- list(make_subj("a", 1), make_subj("b", 2))

  base <- dkge_data(subs)
  pinned <- dkge_data(subs, effects = c("eff3", "eff1", "eff2"))
  perm <- match(pinned$effects, base$effects)

  expect_equal(unname(pinned$effect_n[[1]]), unname(base$effect_n[[1]])[perm])
  expect_equal(names(pinned$effect_n[[1]]), pinned$effects)
  expect_equal(unname(pinned$effect_precision[[2]]),
               unname(base$effect_precision[[2]])[perm])
  expect_equal(unname(pinned$effect_noise_cov[[1]]),
               unname(base$effect_noise_cov[[1]][perm, perm]))
  expect_equal(dimnames(pinned$effect_noise_cov[[1]]),
               list(pinned$effects, pinned$effects))
  expect_equal(pinned$split_betas[[1]][[1]],
               base$split_betas[[1]][[1]][perm, , drop = FALSE])
  expect_equal(pinned$betas[[1]], base$betas[[1]][perm, , drop = FALSE])
})

test_that("dkge_data rejects effects that no subject observes", {
  effects <- c("eff1", "eff2", "eff3")
  design <- matrix(rnorm(30), 10, 3, dimnames = list(NULL, effects))
  beta <- matrix(rnorm(12), 3, 4, dimnames = list(effects, NULL))
  subs <- list(
    dkge_subject(beta, design = design, id = "a", observed_rows = c(1L, 2L)),
    dkge_subject(beta, design = design, id = "b", observed_rows = c(1L, 2L))
  )
  expect_error(dkge_data(subs), "observed by no subject: eff3")
})

test_that("dkge_subject.list forwards observed_rows and reliability metadata", {
  effects <- c("eff1", "eff2", "eff3")
  design <- matrix(rnorm(30), 10, 3, dimnames = list(NULL, effects))
  beta <- matrix(rnorm(12), 3, 4, dimnames = list(effects, NULL))
  subj <- dkge_subject(list(
    beta = beta,
    design = design,
    id = "s7",
    observed_rows = c(1L, 3L),
    effect_n = stats::setNames(c(4, 0, 9), effects)
  ))
  expect_s3_class(subj, "dkge_subject")
  expect_equal(subj$id, "s7")
  expect_equal(subj$observed_rows, c(1L, 3L))
  expect_equal(unname(subj$effect_n), c(4, 0, 9))
})

test_that("effect labels are adopted from whichever side carries them", {
  B <- matrix(rnorm(15), 3, 5, dimnames = list(c("a", "b", "c"), NULL))
  X_unnamed <- matrix(rnorm(30), 10, 3)

  # Named betas + unnamed design: adopt the beta row names rather than
  # inventing effect1..effect3 and then reporting a clash.
  subj <- dkge_subject(B, X_unnamed)
  expect_equal(subj$effects, c("a", "b", "c"))
  expect_equal(colnames(subj$design), c("a", "b", "c"))

  # Unnamed betas + named design: design names win (unchanged behaviour).
  X_named <- X_unnamed
  colnames(X_named) <- c("p", "q", "r")
  subj2 <- dkge_subject(unname(B), X_named)
  expect_equal(subj2$effects, c("p", "q", "r"))

  # Neither labelled: placeholders.
  subj3 <- dkge_subject(unname(B), X_unnamed)
  expect_equal(subj3$effects, paste0("effect", 1:3))

  # Both labelled and disagreeing: still an error.
  X_bad <- X_unnamed
  colnames(X_bad) <- c("a", "b", "zz")
  expect_error(dkge_subject(B, X_bad), "must match design column names")

  expect_error(
    dkge_subject(B, matrix(rnorm(40), 10, 4)),
    "effect-row count \\(3\\) must match design column count \\(4\\)",
    class = "dkge_dimension_error"
  )
})

test_that("dkge_sim_toy output round-trips through dkge()", {
  toy <- dkge_sim_toy(factors = list(A = list(L = 2), B = list(L = 3)),
                      active_terms = c("A", "B"), S = 3, P = 15, snr = 5)
  fit <- dkge(toy$B_list, toy$X_list, K = toy$K, rank = 2)
  expect_equal(fit$rank, 2)
  expect_lt(max(abs(t(fit$U) %*% fit$K %*% fit$U - diag(fit$rank))), 1e-8)
})

test_that("cohort voxel weights are resolved per subject when widths differ", {
  # Uninformative (constant) cohort weights apply to any width.
  expect_equal(dkge:::.dkge_subject_voxel_weights(rep(1, 3), 1L, 5L),
               rep(1, 5))
  expect_equal(dkge:::.dkge_subject_voxel_weights(rep(2, 3), 1L, 5L),
               rep(2, 5))
  # A matching-length vector is passed through untouched.
  expect_equal(dkge:::.dkge_subject_voxel_weights(c(1, 2, 3), 1L, 3L),
               c(1, 2, 3))
  # A varying vector of the wrong width is a real mismatch.
  expect_error(dkge:::.dkge_subject_voxel_weights(c(1, 2, 3), 1L, 5L, "s1"),
               "do not apply to subject s1")
  # Per-subject lists are indexed, not recycled.
  expect_equal(
    dkge:::.dkge_subject_voxel_weights(list(c(1, 2), c(3, 4, 5)), 2L, 3L),
    c(3, 4, 5)
  )
  expect_null(dkge:::.dkge_subject_voxel_weights(NULL, 1L, 4L))
})

test_that("subjects with different cluster counts fit under cohort weights", {
  set.seed(4)
  effects <- paste0("e", 1:3)
  design <- matrix(rnorm(30), 10, 3, dimnames = list(NULL, effects))
  widths <- c(4L, 7L, 5L)
  betas <- lapply(widths, function(P) {
    matrix(rnorm(3 * P), 3, P, dimnames = list(effects, NULL))
  })
  fit <- dkge_fit(betas, replicate(3, design, simplify = FALSE),
                  K = diag(3), rank = 2, keep_X = TRUE)
  expect_equal(vapply(fit$Btil, ncol, integer(1)), widths)
  expect_equal(fit$Chat, tcrossprod(fit$X_concat),
               tolerance = 1e-10, ignore_attr = TRUE)
})

test_that("dkge_data stamps normalised ids onto the subject objects", {
  d <- dkge_data(lapply(c(4, 6), function(p) matrix(rnorm(3 * p), 3, p)),
                 designs = list(diag(3), diag(3)))
  expect_equal(d$subject_ids, c("sub01", "sub02"))
  expect_equal(vapply(d$subjects, function(s) s$id, character(1)),
               c("sub01", "sub02"))
})
