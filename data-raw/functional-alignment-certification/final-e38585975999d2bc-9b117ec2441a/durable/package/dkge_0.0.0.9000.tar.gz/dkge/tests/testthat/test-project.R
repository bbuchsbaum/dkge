# test-project.R
# Diagnostics for projection and prediction helpers

library(testthat)
library(dkge)

make_projection_fixture <- function(S = 3, q = 3, P = 4, Tn = 40, seed = 123) {
  set.seed(seed)
  effects <- paste0("eff", seq_len(q))
  betas <- replicate(S, {
    mat <- matrix(rnorm(q * P), q, P)
    rownames(mat) <- effects
    mat
  }, simplify = FALSE)
  designs <- replicate(S, {
    X <- matrix(rnorm(Tn * q), Tn, q)
    X <- qr.Q(qr(X))
    colnames(X) <- effects
    X
  }, simplify = FALSE)
  omega <- replicate(S, runif(P, min = 0.5, max = 1.5), simplify = FALSE)
  centroids <- replicate(S, matrix(runif(P * 3), P, 3), simplify = FALSE)
  list(betas = betas, designs = designs, omega = omega, effects = effects,
       centroids = centroids)
}

context_fixture <- make_projection_fixture()

fit_fixture <- dkge_fit(dkge_data(context_fixture$betas,
                                  designs = context_fixture$designs,
                                  omega = context_fixture$omega),
                        K = diag(length(context_fixture$effects)),
                        rank = 2,
                        keep_X = TRUE)

test_that("subject weights shrink correctly", {
  Btil <- list(matrix(1, 2, 3), matrix(2, 2, 3))
  Khalf <- diag(2)
  w_raw_expected <- c(1 / sum(Btil[[1]]^2), 1 / sum(Btil[[2]]^2))
  w_norm_expected <- w_raw_expected / mean(w_raw_expected)
  w0 <- dkge:::.dkge_subject_weights(Btil, list(NULL, NULL), Khalf,
                                     w_method = "energy", w_tau = 0)
  w1 <- dkge:::.dkge_subject_weights(Btil, list(NULL, NULL), Khalf,
                                     w_method = "energy", w_tau = 1)
  expect_equal(w0, w_norm_expected, tolerance = 1e-10)
  expect_equal(w1, rep(1, 2))
})

test_that("Omega vector accumulation matches sqrt weighting", {
  B <- list(matrix(c(1, 2, 3, 4), 2, 2))
  Omega <- list(c(1.5, 0.5))
  Khalf <- diag(2)
  R <- diag(2)
  res <- dkge:::.dkge_build_moment_pool(
    subjects = list(list(id = "s1")),
    B_list = B,
    Omega_list = Omega,
    voxel_weights = NULL,
    obs_masks = list(rep(TRUE, 2)),
    subject_weights = 1,
    effect_precision = list(rep(1, 2)),
    effect_method = "none",
    R = R,
    Khalf = Khalf,
    missingness = "none",
    miss_args = list(),
    debias = "none"
  )
  W <- B[[1]] * rep(sqrt(Omega[[1]]), each = 2)
  expected <- Khalf %*% (W %*% t(W)) %*% Khalf
  expect_equal(res$contribs[[1]], expected)
  expect_equal(res$Chat, expected)
})

test_that("preprocess recreates training blocks", {
  X_new <- dkge_preprocess_blocks(fit_fixture,
                                  context_fixture$betas,
                                  fit_fixture$Omega,
                                  fit_fixture$weights)
  expect_equal(X_new, fit_fixture$X_concat, tolerance = 1e-10, ignore_attr = TRUE)
})

test_that("project blocks reproduces training scores", {
  scores <- dkge_project_blocks(fit_fixture,
                                context_fixture$betas,
                                fit_fixture$Omega,
                                fit_fixture$weights)
  expect_equal(scores, fit_fixture$s, tolerance = 1e-10, ignore_attr = TRUE)
})

test_that("cluster projection matches training loadings", {
  for (s in seq_along(context_fixture$betas)) {
    osm <- context_fixture$omega[[s]]
    for (j in seq_len(ncol(context_fixture$betas[[s]]))) {
      omega_j <- if (is.null(osm)) 1 else osm[j]
      proj <- dkge_project_cluster(fit_fixture,
                                   context_fixture$betas[[s]][, j],
                                   omega = omega_j,
                                   w = fit_fixture$weights[s])
  expect_equal(proj, fit_fixture$v[fit_fixture$block_indices[[s]][j], ],
               tolerance = 1e-8, ignore_attr = TRUE)
    }
  }
})

test_that("predict loadings reproduce training loadings", {
  preds <- dkge_predict_loadings(fit_fixture, context_fixture$betas)
  expected <- lapply(fit_fixture$Btil, function(Bts) t(Bts) %*% fit_fixture$K %*% fit_fixture$U)
  expect_equal(preds, expected, tolerance = 1e-10, ignore_attr = TRUE)
})

test_that("predict respects effect reordering", {
  shuffled <- lapply(context_fixture$betas, function(mat) mat[rev(seq_len(nrow(mat))), , drop = FALSE])
  preds_shuffled <- dkge_predict_loadings(fit_fixture, shuffled)
  preds <- dkge_predict_loadings(fit_fixture, context_fixture$betas)
  expect_equal(preds_shuffled, preds, tolerance = 1e-10, ignore_attr = TRUE)
})

test_that("dkge_predict preserves subject identifiers", {
  subjects <- lapply(seq_along(context_fixture$betas), function(s) {
    dkge_subject(context_fixture$betas[[s]],
                 design = context_fixture$designs[[s]],
                 id = paste0("sub", s))
  })
  contrast <- diag(length(context_fixture$effects))[, 1]
  res <- dkge_predict(fit_fixture, subjects, list(c1 = contrast))
  expect_equal(names(res$values), paste0("sub", seq_along(subjects)))
  expect_equal(names(res$A_list), paste0("sub", seq_along(subjects)))
})

test_that("dkge_predict zero-fills missing effects and reports coverage", {
  partial_beta <- context_fixture$betas[[1]][-1, , drop = FALSE]
  partial_design <- context_fixture$designs[[1]][, -1, drop = FALSE]
  subj <- dkge_subject(partial_beta, design = partial_design, id = "partial")
  contrast <- setNames(rep(0, length(context_fixture$effects)), context_fixture$effects)
  contrast[1] <- 1
  res <- dkge_predict(fit_fixture,
                      B_list = list(subj),
                      contrasts = list(main = contrast),
                      return_loadings = FALSE)
  expect_equal(names(res$coverage_rows), "partial")
  cov_vec <- res$coverage_rows[["partial"]]
  expect_false(cov_vec[1])
  expect_true(all(cov_vec[-1]))
  expect_equal(length(cov_vec), length(context_fixture$effects))
})


test_that("latent loadings self-transport the reference", {
  centroids <- context_fixture$centroids
  loadings <- dkge_predict_loadings(fit_fixture, context_fixture$betas)
  transport <- suppressWarnings(dkge_transport_loadings_to_medoid(fit_fixture, medoid = 1,
                                                 centroids = centroids,
                                                 loadings = loadings))
  first_component <- transport$subjects[[1]][1, ]
  expect_equal(first_component,
               as.numeric(transport$cache$operators[[1]] %*% loadings[[1]][, 1]),
               tolerance = 1e-8)
})

test_that("legacy contrast transport applies the fitted self-map", {
  centroids <- context_fixture$centroids
  contrast <- dkge_contrast(fit_fixture, c(1, -1, 0), method = "loso")
  res <- suppressWarnings(dkge_transport_contrasts_to_medoid(
    fit_fixture, contrast, medoid = 1, centroids = centroids
  ))
  first_subject <- res[[1]]$subj_values[1, ]
  base_vals <- contrast$values[[1]][[1]]
  expect_equal(first_subject,
               as.numeric(res[[1]]$operators[[1]] %*% base_vals),
               tolerance = 1e-8)
})

test_that("transform of a training subject applies the voxel prior", {
  set.seed(21)
  S <- 2; q <- 3; P <- 4
  effects <- paste0("e", seq_len(q))
  betas <- replicate(S, {
    B <- matrix(rnorm(q * P), q, P)
    dimnames(B) <- list(effects, paste0("v", seq_len(P)))
    B
  }, simplify = FALSE)
  designs <- replicate(S, {
    X <- diag(q)
    colnames(X) <- effects
    X
  }, simplify = FALSE)
  prior <- c(0.2, 1, 3, 0.5)
  fit <- dkge_fit(betas, designs, K = diag(q), rank = 2, keep_X = TRUE,
                  w_method = "none",
                  weights = dkge_weights(prior = prior, adapt = "none"))

  expect_error(dkge_transform_block(fit, betas[[1]], w_s = fit$weights[1]),
               "subject")

  block <- fit$X_concat[, fit$block_indices[[1]], drop = FALSE]
  transformed <- dkge_transform_block(fit, betas[[1]], w_s = fit$weights[1],
                                      subject = 1)
  expect_equal(unname(transformed), unname(block), tolerance = 1e-12)

  by_id <- dkge_transform_block(fit, betas[[1]], w_s = fit$weights[1],
                                subject = fit$subject_ids[[1]])
  expect_equal(unname(by_id), unname(block), tolerance = 1e-12)
})

test_that("preprocess_blocks keeps new-data column names", {
  set.seed(22)
  q <- 3; P <- 4
  effects <- paste0("e", seq_len(q))
  train <- replicate(2, {
    B <- matrix(rnorm(q * P), q, P)
    dimnames(B) <- list(effects, paste0("train", seq_len(P)))
    B
  }, simplify = FALSE)
  designs <- replicate(2, {
    X <- diag(q)
    colnames(X) <- effects
    X
  }, simplify = FALSE)
  fit <- dkge_fit(train, designs, K = diag(q), rank = 2, keep_X = TRUE,
                  w_method = "none")

  new_betas <- lapply(train, function(B) {
    B2 <- B + 0.1
    colnames(B2) <- paste0("new", seq_len(P))
    B2
  })
  X_new <- dkge_preprocess_blocks(fit, new_betas, w = fit$weights)
  expect_equal(colnames(X_new),
               c(paste0("new", seq_len(P)), paste0("new", seq_len(P))))
  expect_false(identical(colnames(X_new), colnames(fit$X_concat)))
})
