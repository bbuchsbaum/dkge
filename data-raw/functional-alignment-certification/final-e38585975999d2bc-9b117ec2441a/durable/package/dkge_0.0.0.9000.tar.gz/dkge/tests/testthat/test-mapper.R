# test-mapper.R
# Direct tests for mapper specification, fitting, and prediction.

library(testthat)

test_that("sinkhorn mapper produces balanced transport plan", {
  source_feat <- matrix(c(0, 0,
                          1, 0), nrow = 2, byrow = TRUE)
  target_feat <- matrix(c(0, 0,
                          2, 0), nrow = 2, byrow = TRUE)

  spec <- dkge_mapper_spec("sinkhorn", epsilon = 0.1, lambda_spa = 0)
  mapping <- fit_mapper(spec, source_feat = source_feat, target_feat = target_feat)

  plan <- mapping$plan
  expect_lt(max(abs(rowSums(plan) - 0.5)), 5e-3)
  expect_lt(max(abs(colSums(plan) - 0.5)), 5e-3)

  values <- c(3, 7)
  mapped <- predict_mapper(mapping, values)
  expect_equal(mapped, as.numeric(t(mapping$operator) %*% values), tolerance = 1e-8)
})

test_that("ridge mapper matches closed-form solution", {
  source_feat <- diag(3)
  target_feat <- matrix(c(1, 2, 0,
                          0, 1, 3,
                          2, 0, 1), nrow = 3, byrow = TRUE)
  spec <- dkge_mapper_spec("ridge", lambda = 0)
  mapping <- fit_mapper(spec, source_feat = source_feat, target_feat = target_feat)

  expect_equal(mapping$operator, t(target_feat), tolerance = 1e-10)

  vals <- c(5, 4, -1)
  expect_equal(predict_mapper(mapping, vals), as.numeric(target_feat %*% vals), tolerance = 1e-10)
})

test_that("ridge mapper applies regularisation", {
  source_feat <- diag(2)
  target_feat <- matrix(c(2, 0,
                          0, 2), nrow = 2, byrow = TRUE)
  spec <- dkge_mapper_spec("ridge", lambda = 1)
  mapping <- fit_mapper(spec, source_feat = source_feat, target_feat = target_feat)
  expect_equal(mapping$operator, diag(2 / (1 + 1), 2), tolerance = 1e-10)
})

test_that("ridge mapper matches n-by-n solve with regularisation", {
  set.seed(99)
  source_feat <- matrix(rnorm(5 * 3), 5, 3)
  target_feat <- matrix(rnorm(4 * 3), 4, 3)
  lambda <- 0.2

  spec <- dkge_mapper_spec("ridge", lambda = lambda)
  mapping <- fit_mapper(spec, source_feat = source_feat, target_feat = target_feat)

  A <- as.matrix(source_feat)
  B <- as.matrix(target_feat)
  G <- A %*% t(A)
  if (lambda > 0) {
    G <- G + diag(lambda, nrow(G))
  }
  rhs <- A %*% t(B)
  legacy_coeff <- solve(G, rhs)

  expect_equal(mapping$operator, legacy_coeff, tolerance = 1e-8)
})

test_that("sinkhorn mapper solves near-identity transport when supports align", {
  subj_points <- matrix(c(0, 0, 0,
                          1, 0, 0), ncol = 3, byrow = TRUE)
  anchor_points <- subj_points
  mapper <- dkge_mapper("sinkhorn",
                        epsilon = 1e-3,
                        sigx = 1,
                        lambda_xyz = 1)
  fit <- fit_mapper(mapper,
                    subj_points = subj_points,
                    anchor_points = anchor_points)
  plan <- fit$plan
  expect_equal(Matrix::rowSums(plan), rep(0.5, 2), tolerance = 1e-6)
  expect_equal(Matrix::colSums(plan), rep(0.5, 2), tolerance = 1e-6)

  vals <- c(-2, 4)
  mapped <- apply_mapper(fit, vals)
  expect_equal(mapped, vals, tolerance = 1e-2)
})


test_that("sinkhorn mapper honours reliability weights", {
  subj_points <- matrix(c(0, 0, 0,
                          2, 0, 0,
                          4, 0, 0), ncol = 3, byrow = TRUE)
  anchor_points <- cbind(seq(0, 4, length.out = 5), 0, 0)
  mapper <- dkge_mapper("sinkhorn",
                        epsilon = 5e-3,
                        sigx = 2,
                        lambda_xyz = 1)
  reliab <- c(1, 0.5, 0.25)
  fit <- fit_mapper(mapper,
                    subj_points = subj_points,
                    anchor_points = anchor_points,
                    reliab = reliab)

  values <- c(3, 6, 9)
  mapped <- apply_mapper(fit, values, normalize_by_reliab = TRUE)
  expect_true(all(is.finite(mapped)))
  expect_gt(max(mapped), min(mapped))
})

test_that("sinkhorn mapper applies conditional fields without double reliability", {
  plan_mat <- Matrix::Matrix(matrix(c(0.3, 0.1,
                                      0.3, 0.3), nrow = 2), sparse = TRUE)
  mu <- c(0.6, 0.4)
  nu <- c(0.4, 0.6)
  operator <- sweep(as.matrix(plan_mat), 2, nu, "/")
  mapper <- list(plan = plan_mat,
                 operator = Matrix::Matrix(operator, sparse = TRUE),
                 mu = mu,
                 nu = nu,
                 P = 2L,
                 Q = 2L,
                 reliab = c(9, 1),
                 epsilon = 0.1,
                 max_iter = 50L,
                 tol = 1e-6)
  class(mapper) <- "dkge_mapper_fit_sinkhorn"

  values <- matrix(c(1, 4,
                     2, -3), nrow = 2)

  vectorised <- apply_mapper(mapper, values, normalize_by_reliab = TRUE)
  manual <- t(operator) %*% values
  expect_equal(vectorised, manual)
  expect_equal(apply_mapper(mapper, rep(4, 2)), rep(4, 2), tolerance = 1e-12)

  post_fit_reliab <- c(1, 3)
  reweighted <- apply_mapper(mapper, values, reliab = post_fit_reliab)
  plan_t <- Matrix::t(plan_mat)
  denom <- as.numeric(plan_t %*% post_fit_reliab)
  reweight_oracle <- sweep(as.matrix(plan_t %*% (values * post_fit_reliab)),
                           1, denom, "/")
  expect_equal(reweighted, reweight_oracle)

  unnorm <- apply_mapper(mapper, values, normalize_by_reliab = FALSE)
  expect_equal(unnorm, as.matrix(plan_t %*% values))
})

test_that("sinkhorn mapper leverages features when geometry is ambiguous", {
  subj_points <- matrix(0, nrow = 2, ncol = 3)
  anchor_points <- matrix(0, nrow = 2, ncol = 3)
  subj_feats <- rbind(c(1, 0), c(0, 1))
  anchor_feats <- rbind(c(1, 0), c(0, 1))

  mapper <- dkge_mapper("sinkhorn",
                        epsilon = 1e-3,
                        lambda_xyz = 0,
                        lambda_feat = 1,
                        sigz = 1)
  fit <- fit_mapper(mapper,
                    subj_points = subj_points,
                    anchor_points = anchor_points,
                    subj_feats = subj_feats,
                    anchor_feats = anchor_feats)

  plan <- as.matrix(fit$plan)
  expect_gt(plan[1, 1], 0.45)
  expect_gt(plan[2, 2], 0.45)
  expect_lt(plan[1, 2], 0.05)
  expect_lt(plan[2, 1], 0.05)
})

test_that("knn mapper accumulates contributions when clusters share an anchor", {
  # Two source clusters (1, 2) map to anchor 1; cluster 3 maps to anchor 2.
  # The buggy scatter-add `anchor[js] <- anchor[js] + ...` kept only the last
  # write, dropping cluster 1's contribution to anchor 1.
  fit <- structure(
    list(type = "knn",
         idx = matrix(c(1L, 1L, 2L), nrow = 3, ncol = 1),
         weights = matrix(1, nrow = 3, ncol = 1),
         Q = 2L,
         P = 3L,
         reliab = NULL),
    class = "dkge_mapper_fit_knn"
  )
  values <- c(2, 4, 7)

  unnorm <- apply_mapper(fit, values, normalize_by_reliab = FALSE)
  expect_equal(unnorm, c(2 + 4, 7))

  norm <- apply_mapper(fit, values, normalize_by_reliab = TRUE)
  expect_equal(norm, c((2 + 4) / 2, 7))
})

test_that("knn mapper reliability weighting handles shared anchors", {
  fit <- structure(
    list(type = "knn",
         idx = matrix(c(1L, 1L, 2L), nrow = 3, ncol = 1),
         weights = matrix(1, nrow = 3, ncol = 1),
         Q = 2L,
         P = 3L,
         reliab = NULL),
    class = "dkge_mapper_fit_knn"
  )
  values <- c(2, 4, 7)
  r <- c(1, 3, 1)
  # anchor 1 = sum(r*w*value) / sum(r*w) = (1*2 + 3*4) / (1 + 3) = 14/4
  out <- apply_mapper(fit, values, reliab = r, normalize_by_reliab = TRUE)
  expect_equal(out, c((1 * 2 + 3 * 4) / (1 + 3), 7))
})
