# dkge-project.R
# Projection helpers wrapping the multivarious interface for DKGE objects.

#' Require an exact subject-by-voxel block factor
#'
#' @keywords internal
#' @noRd
.dkge_require_block_biprojector <- function(fit, operation) {
  representation <- fit$representation %||% "block_biprojector"
  if (!identical(representation, "block_biprojector") || is.null(fit$v)) {
    reasons <- fit$representation_reasons %||% "the fitted moment is q-space only"
    stop(sprintf(
      paste0("%s requires representation='block_biprojector', but this fit uses ",
             "representation='%s' (%s). Use q-space loadings or contrast ",
             "functions instead."),
      operation, representation, paste(reasons, collapse = "; ")
    ), call. = FALSE)
  }
  invisible(TRUE)
}

#' Fail-closed multivarious methods for q-space DKGE fits
#'
#' Pair-normalized, debiased, ridged, CPCA, and JD fits do not inherit from
#' `multiblock_biprojector`. These methods reject physical block projection
#' instead of inventing incompatible loadings.
#'
#' @param x A `dkge_qspace` fit.
#' @param new_data Unused; required by the multivarious generics.
#' @param ... Unused.
#' @param block,least_squares,from,to,opts Unused arguments of the
#'   corresponding multivarious generics.
#' @name dkge_qspace-multivarious
#' @keywords internal
#' @importFrom multivarious project project_block transfer
#' @exportS3Method multivarious::project
project.dkge_qspace <- function(x, new_data, ...) {
  .dkge_require_block_biprojector(x, "multivarious::project()")
}

#' @rdname dkge_qspace-multivarious
#' @exportS3Method multivarious::project_block
project_block.dkge_qspace <- function(x, new_data, block, least_squares = TRUE, ...) {
  .dkge_require_block_biprojector(x, "multivarious::project_block()")
}

#' @rdname dkge_qspace-multivarious
#' @exportS3Method multivarious::transfer
transfer.dkge_qspace <- function(x, new_data, from, to, opts = list(), ...) {
  .dkge_require_block_biprojector(x, "multivarious::transfer()")
}

#' Preprocess a subject block into DKGE training space
#'
#' Applies the same transformations used during fitting (pooled design Cholesky factor,
#' kernel whitening, optional spatial weights, and subject weighting) to a
#' subject's beta matrix.
#'
#' @param fit A `dkge` object.
#' @param B_s qxP matrix of subject betas.
#' @param Omega_s Optional weights (vector length P or PxP matrix) matching the
#'   columns of `B_s`.
#' @param w_s Optional subject-level weight (defaults to 1 when omitted).
#' @param subject Optional training-subject index or id. Required when the fit
#'   carries non-trivial voxel weights, so the matching
#'   `fit$voxel_weights_subject` / `fit$voxel_weights` profile can be applied.
#' @return qxP matrix in the DKGE training space.
#' @export
dkge_transform_block <- function(fit, B_s, Omega_s = NULL, w_s = NULL,
                                 subject = NULL) {
  stopifnot(inherits(fit, "dkge"))
  effects <- fit$effects
  B_s <- as.matrix(B_s)
  if (!is.null(effects)) {
    stopifnot(nrow(B_s) == length(effects))
    if (!is.null(rownames(B_s))) {
      idx <- match(effects, rownames(B_s))
      if (anyNA(idx)) {
        stop("Row names of new betas must cover all training effects.")
      }
      B_s <- B_s[idx, , drop = FALSE]
    }
  }
  R <- fit$R
  Khalf <- fit$Khalf
  stopifnot(nrow(B_s) == nrow(R))
  Btil <- t(R) %*% B_s
  vw_spec <- fit$voxel_weights_subject %||% fit$voxel_weights
  if (.dkge_active_voxel_weights(vw_spec)) {
    if (is.null(subject)) {
      stop("This fit carries voxel weights; pass `subject` as a training ",
           "index or id so the matching weights can be applied.",
           call. = FALSE)
    }
    s <- .dkge_resolve_subject(fit, subject)
    vw <- .dkge_subject_voxel_weights(
      vw_spec, s, ncol(Btil),
      fit$subject_ids[[s]] %||% as.character(s)
    )
    Btil <- .dkge_scale_effect_columns(Btil, vw)
  }
  if (!is.null(fit$spatial) && isTRUE(fit$spatial$active)) {
    if (is.null(subject) && !isTRUE(fit$spatial$shared)) {
      stop("This fit carries subject-specific spatial regularization; pass `subject`.",
           call. = FALSE)
    }
    Btil <- .dkge_apply_fit_spatial(fit, Btil, subject = subject)
  }
  if (!is.null(Omega_s)) {
    if (is.vector(Omega_s)) {
      stopifnot(length(Omega_s) == ncol(Btil))
      Btil <- Btil * rep(sqrt(as.numeric(Omega_s)), each = nrow(Btil))
    } else {
      Omega_s <- as.matrix(Omega_s)
      stopifnot(nrow(Omega_s) == ncol(Btil), ncol(Omega_s) == ncol(Btil))
      Btil <- Btil %*% sqrtm_sym(Omega_s)
    }
  }
  weight <- if (is.null(w_s)) 1 else sqrt(max(as.numeric(w_s), 0))
  weight * (Khalf %*% Btil)
}

#' Preprocess multiple blocks into the DKGE training space
#'
#' @param fit A `dkge` object returned by [dkge_fit()].
#' @param B_list List of subject beta matrices.
#' @param Omega_list Optional list of spatial weights aligned with `B_list`.
#' @param w Optional vector of subject weights for the new data.
#' @return qx(sum P_s) matrix matching the training block layout.
#' @export
dkge_preprocess_blocks <- function(fit, B_list, Omega_list = NULL, w = NULL) {
  stopifnot(inherits(fit, "dkge"))
  .dkge_require_block_biprojector(fit, "dkge_preprocess_blocks()")
  S <- length(B_list)
  if (is.null(Omega_list)) Omega_list <- vector("list", S)
  if (is.null(w)) w <- rep(1, S)
  stopifnot(length(Omega_list) == S, length(w) == S)
  total_cols <- nrow(fit$v)
  q <- nrow(fit$U)
  X <- matrix(0, q, total_cols)
  for (s in seq_len(S)) {
    idx <- fit$block_indices[[s]]
    Xs <- dkge_transform_block(fit, B_list[[s]], Omega_list[[s]], w[s],
                               subject = s)
    if (ncol(Xs) != length(idx)) {
      stop(sprintf("Block %d produced %d columns but %d were expected.",
                   s, ncol(Xs), length(idx)))
    }
    X[, idx] <- Xs
    if (!is.null(colnames(Xs))) {
      cn <- colnames(X)
      if (is.null(cn)) cn <- rep(NA_character_, ncol(X))
      cn[idx] <- colnames(Xs)
      colnames(X) <- cn
    }
  }
  X
}

#' Project new blocks into DKGE score space
#'
#' @param fit A `dkge` object.
#' @inheritParams dkge_preprocess_blocks
#' @return Matrix of projected scores (qxrank).
#' @keywords internal
#' @export
dkge_project_blocks <- function(fit, B_list, Omega_list = NULL, w = NULL) {
  .dkge_require_block_biprojector(fit, "dkge_project_blocks()")
  Xnew <- dkge_preprocess_blocks(fit, B_list, Omega_list, w)
  multivarious::project(fit, Xnew)
}

#' @title Project DKGE data into component space
#'
#' @description Functions for projecting subject-standardised betas or new blocks into DKGE component coordinates.
#' @param fit A `dkge` object.
#' @param s Block index (subject) to project against.
#' @param B_s Beta matrix for the new data block.
#' @inheritParams dkge_transform_block
#' @param least_squares Logical; pass to [multivarious::project_block()].

#' @description Convenience wrapper for projecting row-standardised betas onto DKGE components.
#' @param fit A `dkge` object.
#' @param Btil Either a qxP matrix or a list of such matrices (e.g. `fit$Btil`).
#' @param subject Optional training-subject index or id for a single matrix.
#'   Required when the fit uses subject-specific spatial regularization. A list
#'   is matched to fitted subjects positionally.
#' @return List of Pxrank matrices; returns a single matrix when `Btil` is a matrix.
#' @describeIn dkge_project_block Project subject-standardised betas into component space
#' @keywords internal
#' @export
#' @examples
#' toy <- dkge_sim_toy(
#'   factors = list(A = list(L = 2), B = list(L = 3)),
#'   active_terms = c("A", "B"), S = 3, P = 20, snr = 5
#' )
#' fit <- dkge_fit(toy$B_list, toy$X_list, toy$K, rank = 2)
#' A <- dkge_project_btil(fit, fit$Btil[[1]])
#' dim(A)
dkge_project_btil <- function(fit, Btil, subject = NULL) {
  stopifnot(inherits(fit, "dkge"))
  KsU <- fit$K %*% fit$U
  project_one <- function(mat, s = NULL) {
    mat <- as.matrix(mat)
    stopifnot(nrow(mat) == nrow(fit$U))
    mat <- .dkge_apply_fit_spatial(fit, mat, subject = s)
    t(mat) %*% KsU
  }
  if (is.list(Btil)) {
    if (length(Btil) != length(fit$Btil)) {
      stop("A beta-block list must have one entry per fitted subject.",
           call. = FALSE)
    }
    out <- lapply(seq_along(Btil), function(s) project_one(Btil[[s]], s))
    names(out) <- names(Btil) %||% fit$subject_ids
    out
  } else {
    project_one(Btil, subject)
  }
}

#' Project a single block against its training block index
#'
#' @param fit A `dkge` object.
#' @param s Block index (subject) to project against.
#' @param B_s Beta matrix for the new data block.
#' @inheritParams dkge_transform_block
#' @param least_squares Logical; pass to [multivarious::project_block()].
#' @return Projection scores (qxrank) restricted to block `s`.
#' @rdname dkge_project_block
#' @keywords internal
#' @export
dkge_project_block <- function(fit, s, B_s, Omega_s = NULL, w_s = NULL,
                               least_squares = TRUE) {
  stopifnot(inherits(fit, "dkge"))
  .dkge_require_block_biprojector(fit, "dkge_project_block()")
  stopifnot(s >= 1L, s <= length(fit$block_indices))
  Xs <- dkge_transform_block(fit, B_s, Omega_s, w_s, subject = s)
  if (ncol(Xs) != length(fit$block_indices[[s]])) {
    stop("New block has different width than training block.")
  }
  multivarious::project_block(fit, new_data = Xs, block = s,
                              least_squares = least_squares)
}

#' Project a new cluster/voxel vector onto DKGE components
#'
#' @param fit A `dkge` object.
#' @param b Numeric vector of length q (effects).
#' @param omega Optional scalar or matrix weight.
#' @param w Optional scalar subject weight.
#' @return Numeric vector of length `rank` (component scores).
#' @keywords internal
#' @export
dkge_project_cluster <- function(fit, b, omega = 1, w = 1) {
  stopifnot(inherits(fit, "dkge"))
  .dkge_require_block_biprojector(fit, "dkge_project_cluster()")
  if (!is.null(fit$spatial) && isTRUE(fit$spatial$active)) {
    .dkge_abort(
      paste0(
        "`dkge_project_cluster()` cannot apply a spatial regularizer to one ",
        "isolated unit. Project the complete spatial block with ",
        "`dkge_project_clusters()`."
      ),
      "dkge_spatial_projection_error"
    )
  }
  b <- as.numeric(b)
  stopifnot(length(b) == nrow(fit$U))
  ctil <- t(fit$R) %*% matrix(b, ncol = 1)
  if (is.matrix(omega)) {
    ctil <- ctil %*% sqrtm_sym(omega)
  } else {
    ctil <- ctil * sqrt(as.numeric(omega))
  }
  x <- sqrt(max(as.numeric(w), 0)) * (fit$Khalf %*% ctil)
  U_hat <- fit$Khalf %*% fit$U
  inv_sdev <- if (length(fit$sdev)) ifelse(fit$sdev > 0, 1 / fit$sdev, 0) else numeric(0)
  U_scaled <- if (length(inv_sdev)) sweep(U_hat, 2, inv_sdev, `*`) else U_hat
  as.numeric(t(x) %*% U_scaled)
}

#' Project multiple cluster/voxel vectors
#'
#' @param fit A `dkge` object.
#' @param B qxP matrix of cluster betas.
#' @param omega_vec Optional vector of per-cluster weights.
#' @param w Optional subject weight.
#' @param subject Optional training-subject index or id used to select a
#'   subject-specific spatial operator.
#' @return Pxrank matrix of projected coordinates.
#' @keywords internal
#' @export
dkge_project_clusters <- function(fit, B, omega_vec = NULL, w = 1,
                                  subject = NULL) {
  stopifnot(inherits(fit, "dkge"))
  .dkge_require_block_biprojector(fit, "dkge_project_clusters()")
  B <- as.matrix(B)
  stopifnot(nrow(B) == nrow(fit$U))
  ctil <- t(fit$R) %*% B
  ctil <- .dkge_apply_fit_spatial(fit, ctil, subject = subject)
  if (!is.null(omega_vec)) {
    stopifnot(length(omega_vec) == ncol(B))
    ctil <- ctil * rep(sqrt(as.numeric(omega_vec)), each = nrow(ctil))
  }
  x <- sqrt(max(as.numeric(w), 0)) * (fit$Khalf %*% ctil)
  U_hat <- fit$Khalf %*% fit$U
  inv_sdev <- if (length(fit$sdev)) ifelse(fit$sdev > 0, 1 / fit$sdev, 0) else numeric(0)
  U_scaled <- if (length(inv_sdev)) sweep(U_hat, 2, inv_sdev, `*`) else U_hat
  t(x) %*% U_scaled
}
