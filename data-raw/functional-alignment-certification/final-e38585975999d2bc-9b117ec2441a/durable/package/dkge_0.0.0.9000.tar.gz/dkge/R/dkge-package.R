#' dkge: Design-Kernel Group Embedding
#'
#' Core routines for design-aware group embedding, cross-validated contrasts, and transport utilities.
#'
#' @keywords internal
#' @importFrom stats aggregate contr.helmert contr.sum p.adjust pt setNames
#' @importFrom utils head
"_PACKAGE"

#' DKGE glossary
#'
#' Definitions for the terms the DKGE documentation uses most. Each one states
#' what the package does, not what the word means elsewhere.
#'
#' @section Effect space:
#' The shared coordinate system in which DKGE works. Each subject's beta matrix
#' has one row per named design effect, so the rows mean the same thing across
#' subjects even when the columns (clusters) do not. That row space is the
#' effect space, and its dimension `q` is the number of design effects. The
#' design kernel `K` supplies the metric on it.
#'
#' @section Design kernel:
#' A `q` by `q` positive semidefinite matrix stating which design effects should
#' be treated as similar. It expresses a scientific belief you can name, such as
#' adjacent ordinal levels being related. It is not a tuning matrix, and
#' `diag(q)` is the honest choice when the structure is uncertain. See
#' [design_kernel()].
#'
#' @section Salience:
#' The design-weighted component coordinates, \eqn{K U}. Rows are effects or
#' design cells and columns are latent components, so reading down a column
#' shows which effects a component combines. See [dkge_component_saliences()].
#'
#' @section Cross-fitting:
#' Evaluating a subject through a basis their own data did not shape. The
#' leave-one-subject-out path removes subject `s` from the pooled compressed
#' covariance, re-derives the basis by eigendecomposition of what remains, and
#' reads that subject's values through it. K-fold cross-fitting does the same
#' with folds instead of single subjects. It limits basis-reuse optimism; it
#' does not supply a population p-value.
#'
#' @section Reference support:
#' The coordinates, labels, topology, and optional decoder on which aligned
#' values are represented. A subject parcellation or fixed anatomical/MNI grid
#' can supply support. Coordinates alone contain no functional correspondence
#' and no participant's activation values. See [dkge_reference_support()].
#'
#' @section Reference subject and medoid:
#' A reference subject supplies a real subject parcellation as display support.
#' It is a *medoid* only when selected by a stated cohort criterion, such as
#' held-out symmetric functional reconstruction or geometry-only loss. A
#' caller-fixed subject is recorded as an explicit reference, not relabelled a
#' medoid. See [dkge_select_reference_subject()].
#'
#' @section Functional correspondence:
#' The fitted operator that maps a subject's parcels to one reference support.
#' Functional costs must come from typed response-signature features; geometry
#' may regularize or select support but does not become functional data. Every
#' subject, including a reference subject, is fitted through the same mapper
#' policy.
#'
#' @section Functional template:
#' Target response signatures and masses attached to a reference support. A
#' selected subject can initialize a template without becoming privileged
#' functional truth. [dkge_fit_functional_template()] instead pools information
#' across subjects with mass-aware updates and fixed feature scale.
#'
#' @section Aligned subject rows:
#' One contrast row per subject on the same identified support. These rows, not
#' parcels, are the observations for group inference. Fit-level MFA weights are
#' pooling weights for learning the DKGE basis and are not silently reused as
#' contrast inverse-variance weights. Obtain operator-bound rows from
#' [dkge_transport_contrasts_to_reference()] or [dkge_align_to_template()]; the
#' raw [dkge_aligned_maps()] constructor is deliberately descriptive only.
#'
#' @section Group inference:
#' Subject-level inference performed after correspondence has been fixed.
#' [dkge_infer_aligned()] never learns a mapper. It fails closed for ineligible
#' alignments and requires an explicit override for objects labelled
#' approximate by the calibration court.
#'
#' @section Rendering:
#' Display or decoding of an already aligned statistic. A [dkge_renderer()]
#' owns no subject correspondence and cannot turn a bare MNI grid into a
#' functional template.
#'
#' @section Transport:
#' Applying fitted correspondence to move per-cluster values from each
#' subject's parcellation onto a common support. Sinkhorn, ridge, or OLS mappers
#' may implement the operator. Transport is separate from both the shared
#' effect-space metric `K` and downstream rendering.
#'
#' @section LOSO:
#' Leave-one-subject-out. See Cross-fitting.
#'
#' @name dkge-glossary
#' @keywords documentation
NULL
